package com.chayon.keyboard

import android.content.ClipboardManager
import android.content.Context
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class ChayonIME : InputMethodService() {
    private val BG = 0xFF17181B.toInt(); private val KEY = 0xFF2A2B30.toInt(); private val FN = 0xFF202125.toInt()
    private val PRESS = 0xFF3B3D45.toInt(); private val INK = 0xFFF1F2F5.toInt()
    private val SUB = 0xFF9096A3.toInt(); private val ACC = 0xFFE0603C.toInt()
    private val names = listOf("English", "অভ্র", "প্রভাত")
    private val EN = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
    private val HN = listOf("1234567890", "@#&*-!?()", "\"':;/%_")
    private val SY = listOf("1234567890", "@#৳_&-+()/", "*\"':;!?")
    private val PN = listOf(
        listOf("দ", "ূ", "ী", "র", "ট", "এ", "ু", "ি", "ও", "প", "ে", "ো"),
        listOf("া", "স", "ড", "ত", "গ", "হ", "জ", "ক", "ল"),
        listOf("\u09DF", "শ", "চ", "আ", "ব", "ন", "ম", "্", "়"))
    private val PS = listOf(
        listOf("ধ", "ঊ", "ঈ", "\u09DC", "ঠ", "ঐ", "উ", "ই", "ঔ", "ফ", "ৈ", "ৌ"),
        listOf("অ", "ষ", "ঢ", "থ", "ঘ", "ঃ", "ঝ", "খ", "ং"),
        listOf("ৎ", "\u09DD", "ছ", "ঋ", "ভ", "ণ", "ঙ", "ৃ", "ঁ"))
    private val DICT = ("আমি আপনি তুমি করা করে কথা কী কেন কি কোথায় কখন কিভাবে কোনো কত কে কাজ কাল কাছে কিছু কিন্তু কারণ করেছি করছি করব করতে এবং আর বা তবে যদি তাহলে সে তারা আমরা এই ওই এটা যে যা যাই যাবো যাচ্ছি হয় হয়ে হবে হচ্ছে হলো হ্যাঁ না নেই আছে আছি আছেন থাকা থেকে দেখা দিন দিয়ে দিতে বলা বলে বলি বাড়ি বাংলা বাংলাদেশ ভালো ভালোবাসি খুব সুন্দর সময় সবাই সাথে মা বাবা ভাই বোন বন্ধু আজ আজকে এখন এখানে তখন তাই তার তোমার আমার আমাকে আপনার ধন্যবাদ শুভ সকাল রাত দুপুর বিকেল খাওয়া খেয়েছো টাকা পাঠাও ফোন কল মেসেজ নম্বর নাম পড়া লেখা লিখি পারি পারবো চাই চলো আসি আসবো এসো গেলাম নিয়ে পেয়েছি অনেক একটু একটা আবার আরও শুধু দরকার সমস্যা ঠিক ঠিকাছে ওকে হ্যালো সালাম").split(" ")
    private val ENW = ("the be to of and a in that have I it for not on with he as you do at this but his by from they we say her she or an will my one all would there their what so up out if about who get which go me when make can like time no just him know take people into year your good some could them see other than then now look only come its over think also back after use two how our work first well way even new want because any these give day most us is are was were am been being had has did does said went going need love hello thanks please yes okay").split(" ")

    private val AV = HashMap<String, List<String>>().apply {
        mapOf("kh" to "খ", "k" to "ক", "gh" to "ঘ", "g" to "গ", "Ng" to "ঙ", "NG" to "ঞ", "chh" to "ছ", "ch" to "চ", "c" to "চ",
            "jh" to "ঝ", "j" to "জ", "Th" to "ঠ", "T" to "ট", "Dh" to "ঢ", "D" to "ড", "N" to "ণ", "th" to "থ", "t" to "ত",
            "dh" to "ধ", "d" to "দ", "n" to "ন", "ph" to "ফ", "p" to "প", "f" to "ফ", "bh" to "ভ", "b" to "ব", "v" to "ভ",
            "m" to "ম", "z" to "য", "r" to "র", "l" to "ল", "Sh" to "ষ", "sh" to "শ", "S" to "শ", "s" to "স", "h" to "হ",
            "Rh" to "\u09DD", "R" to "\u09DC", "y" to "\u09DF", "Y" to "\u09DF").forEach { (k, v) -> put(k, listOf("c", v)) }
        mapOf("rri" to ("ঋ" to "ৃ"), "oi" to ("ঐ" to "ৈ"), "ou" to ("ঔ" to "ৌ"), "ii" to ("ঈ" to "ী"), "uu" to ("ঊ" to "ূ"),
            "o" to ("অ" to ""), "O" to ("ও" to "ো"), "a" to ("আ" to "া"), "i" to ("ই" to "ি"), "I" to ("ঈ" to "ী"),
            "u" to ("উ" to "ু"), "U" to ("ঊ" to "ূ"), "e" to ("এ" to "ে")).forEach { (k, v) -> put(k, listOf("v", v.first, v.second)) }
        mapOf("ng" to "ং", "^" to "ঁ").forEach { (k, v) -> put(k, listOf("m", v)) }
    }

    private fun trans(r: String): String {
        val sb = StringBuilder(); var prev = ' '; var i = 0
        while (i < r.length) {
            var len = 3; var m: List<String>? = null
            while (len > 0) { if (i + len <= r.length) { m = AV[r.substring(i, i + len)]; if (m != null) break }; len-- }
            if (m == null) { sb.append(r[i]); i++; prev = ' '; continue }
            i += len
            when (m[0]) {
                "c" -> { if (prev == 'c') sb.append('্'); sb.append(m[1]); prev = 'c' }
                "v" -> { sb.append(if (prev == 'c') m[2] else m[1]); prev = 'v' }
                else -> { sb.append(m[1]); prev = 'm' }
            }
        }
        return sb.toString()
    }

    private fun bn(s: String) = s.map { if (it in '0'..'9') "০১২৩৪৫৬৭৮৯"[it - '0'] else it }.joinToString("")

    private lateinit var strip: LinearLayout
    private lateinit var body: LinearLayout
    private lateinit var prefs: android.content.SharedPreferences
    private val sug = arrayOfNulls<TextView>(3)
    private var sugWords = listOf<String>(); private var curPart = ""
    private var lang = 1; private var shift = false; private var layer = "abc"; private var emoCat = 1
    private val roman = StringBuilder()
    private val h = Handler(Looper.getMainLooper())
    private var pop: PopupWindow? = null
    private var lw = JSONObject(); private var bg = JSONObject()
    private val clips = mutableListOf<String>(); private val recent = mutableListOf<String>()
    private val ecache = HashMap<Int, List<String>>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("chayon", 0)
        lang = prefs.getInt("lang", 1)
        try { lw = JSONObject(prefs.getString("lw", "{}")!!); bg = JSONObject(prefs.getString("bg", "{}")!!) } catch (e: Exception) {}
        try { val a = JSONArray(prefs.getString("clips", "[]")); for (i in 0 until a.length()) clips.add(a.getString(i)) } catch (e: Exception) {}
        try { val a = JSONArray(prefs.getString("recent", "[]")); for (i in 0 until a.length()) recent.add(a.getString(i)) } catch (e: Exception) {}
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener {
            try { addClip(cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: "") } catch (e: Exception) {}
        }
    }

    override fun onEvaluateFullscreenMode() = false

    override fun onCreateInputView(): View {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL; root.setBackgroundColor(BG)
        root.setPadding(dp(3), dp(2), dp(3), dp(6))
        strip = LinearLayout(this); body = LinearLayout(this); body.orientation = LinearLayout.VERTICAL
        root.addView(strip, LinearLayout.LayoutParams(-1, dp(40)))
        root.addView(body, LinearLayout.LayoutParams(-1, -2))
        draw()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) { roman.setLength(0); updateSug() }
    override fun onFinishInput() { roman.setLength(0); super.onFinishInput() }
    override fun onUpdateSelection(a: Int, b: Int, c: Int, d: Int, cs: Int, ce: Int) {
        super.onUpdateSelection(a, b, c, d, cs, ce)
        if (cs == -1 && ce == -1) roman.setLength(0)
        updateSug()
    }

    // ---------- views ----------
    private fun bgOf(c: Int): StateListDrawable {
        fun d(x: Int) = GradientDrawable().apply { setColor(x); cornerRadius = dp(9).toFloat() }
        return StateListDrawable().apply { addState(intArrayOf(android.R.attr.state_pressed), d(PRESS)); addState(intArrayOf(), d(c)) }
    }

    private fun keyView(label: String, hint: String, flex: Float, fn: Boolean = false): FrameLayout {
        val f = FrameLayout(this); f.background = bgOf(if (fn) FN else KEY)
        val lp = LinearLayout.LayoutParams(0, dp(55), flex); lp.setMargins(dp(2), 0, dp(2), dp(5)); f.layoutParams = lp
        val t = TextView(this); t.text = label; t.setTextColor(INK); t.textSize = 22f; t.gravity = Gravity.CENTER
        f.addView(t, FrameLayout.LayoutParams(-1, -1))
        if (hint.isNotEmpty()) {
            val hv = TextView(this); hv.text = hint; hv.setTextColor(SUB); hv.textSize = 10f
            f.addView(hv, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(3), dp(5), 0) })
        }
        return f
    }

    private fun gap(f: Float) = View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, f) }
    private fun row() = LinearLayout(this)

    private fun bind(v: View, popText: String?, hint: String?, repeat: Boolean, act: () -> Unit, hintAct: (() -> Unit)? = null) {
        var fired = false
        val lpr = Runnable { fired = true; hintAct?.invoke(); showPop(v, hint ?: "") }
        val rep = object : Runnable { override fun run() { act(); h.postDelayed(this, 60) } }
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.isPressed = true; fired = false
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (popText != null) showPop(v, popText)
                    if (repeat) { act(); h.postDelayed(rep, 400) }
                    else if (hintAct == null) act()
                    else h.postDelayed(lpr, 380)
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false; hidePop(); h.removeCallbacks(lpr); h.removeCallbacks(rep)
                    if (!repeat && hintAct != null && !fired) act()
                }
                MotionEvent.ACTION_CANCEL -> { v.isPressed = false; hidePop(); h.removeCallbacks(lpr); h.removeCallbacks(rep) }
            }
            true
        }
    }

    private fun showPop(v: View, t: String) {
        hidePop()
        val tv = TextView(this).apply {
            text = t; textSize = 32f; gravity = Gravity.CENTER; setTextColor(INK)
            background = GradientDrawable().apply { setColor(KEY); cornerRadius = dp(12).toFloat(); setStroke(dp(1), SUB) }
        }
        val w = maxOf(dp(56), v.width + dp(14)); val ht = dp(62)
        val p = PopupWindow(tv, w, ht); p.isTouchable = false; p.isClippingEnabled = false
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        try { p.showAtLocation(v, Gravity.NO_GRAVITY, loc[0] + v.width / 2 - w / 2, loc[1] - ht - dp(6)); pop = p } catch (e: Exception) {}
    }
    private fun hidePop() { pop?.dismiss(); pop = null }

    private fun draw() {
        body.removeAllViews(); strip.removeAllViews(); hidePop()
        when (layer) {
            "emoji" -> emojiView()
            "clip" -> clipView()
            "sym" -> symRows()
            else -> letters()
        }
        bottom(); buildStrip(); updateSug()
    }

    private fun backKey(): View {
        val b = keyView("⌫", "", 1.5f, true); bind(b, null, null, true, { backspace() }); return b
    }

    private fun letters() {
        val pb = lang == 2
        for (i in 0..2) {
            val r = row()
            val cur: List<String> = if (pb) (if (shift) PS[i] else PN[i]) else EN[i].map { it.toString() }
            if (i == 2) {
                val s = keyView("⇧", "", 1.5f, true)
                (s.getChildAt(0) as TextView).setTextColor(if (shift) ACC else INK)
                bind(s, null, null, false, { shift = !shift; draw() }); r.addView(s)
            }
            if (i == 1) r.addView(gap(if (pb) 0.6f else 0.5f))
            cur.forEachIndexed { j, c ->
                val label = if (!pb && shift) c.uppercase() else c
                val hint = if (pb) (if (shift) "" else PS[i][j]) else HN[i][j].toString()
                val v = keyView(label, hint, if (pb && i == 1) 1.2f else 1f)
                val ha: (() -> Unit)? = if (hint.isEmpty()) null else { { type(hint, false) } }
                bind(v, label, hint, false, { type(label, !pb) }, ha)
                r.addView(v)
            }
            if (i == 1) r.addView(gap(if (pb) 0.6f else 0.5f))
            if (i == 2) r.addView(backKey())
            body.addView(r)
        }
    }

    private fun symRows() {
        for (i in 0..2) {
            val r = row()
            SY[i].forEach { ch ->
                val c = ch.toString(); val lab = if (lang > 0) bn(c) else c
                val v = keyView(lab, "", 1f); bind(v, lab, null, false, { type(c, false) }); r.addView(v)
            }
            if (i == 2) r.addView(backKey())
            body.addView(r)
        }
    }

    private fun bottom() {
        val r = row(); val abc = layer != "abc"
        val k1 = keyView(if (abc) "ABC" else "?123", "", 1.4f, true)
        k1.getChildAt(0).let { (it as TextView).textSize = 16f }
        bind(k1, null, null, false, { layer = if (abc) "abc" else "sym"; draw() })
        val k2 = keyView("☺", "", 1f, true)
        bind(k2, null, null, false, { layer = if (layer == "emoji") "abc" else "emoji"; draw() })
        val k3 = keyView(",", "", 1f); bind(k3, ",", null, false, { type(",", false) })
        val sp = LinearLayout(this); sp.gravity = Gravity.CENTER_VERTICAL; sp.background = bgOf(KEY)
        val sl = LinearLayout.LayoutParams(0, dp(55), 4.5f); sl.setMargins(dp(2), 0, dp(2), dp(5)); sp.layoutParams = sl
        fun arrow(t: String, d: Int) = TextView(this).apply {
            text = t; setTextColor(SUB); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(36), -1)
            setOnTouchListener { _, e ->
                if (e.actionMasked == MotionEvent.ACTION_DOWN) {
                    commitComp(); lang = (lang + d + 3) % 3; shift = false
                    prefs.edit().putInt("lang", lang).apply(); draw()
                }
                true
            }
        }
        val mid = TextView(this).apply { text = names[lang]; setTextColor(SUB); gravity = Gravity.CENTER; textSize = 16f; layoutParams = LinearLayout.LayoutParams(0, -1, 1f) }
        bind(mid, null, null, false, { space() })
        sp.addView(arrow("◀", -1)); sp.addView(mid); sp.addView(arrow("▶", 1))
        val dot = if (lang == 0 || layer == "sym") "." else "।"
        val k5 = keyView(dot, "", 1f); bind(k5, dot, null, false, { type(dot, false) })
        val k6 = keyView("⏎", "", 1.4f); k6.background = bgOf(ACC)
        bind(k6, null, null, false, { enter() })
        listOf(k1, k2, k3, sp, k5, k6).forEach { r.addView(it) }
        body.addView(r)
    }

    private fun smallBtn(t: String, w: Int = 0, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(INK); textSize = 18f; gravity = Gravity.CENTER; setPadding(dp(10), 0, dp(10), 0)
        layoutParams = if (w > 0) LinearLayout.LayoutParams(dp(w), -1) else LinearLayout.LayoutParams(0, -1, 1f)
        setOnClickListener { onClick() }
    }

    private fun buildStrip() {
        when (layer) {
            "abc" -> {
                strip.addView(smallBtn("📋", 44) { layer = "clip"; draw() })
                for (i in 0..2) {
                    val t = smallBtn("") { }
                    t.textSize = 20f; t.maxLines = 1
                    t.setOnTouchListener { _, e ->
                        if (e.actionMasked == MotionEvent.ACTION_DOWN) sugWords.getOrNull(i)?.let { applySug(it) }
                        true
                    }
                    sug[i] = t; strip.addView(t)
                }
            }
            "emoji" -> listOf("🕘", "😀", "🐻", "⚽", "❤️", "🏳️").forEachIndexed { i, t ->
                val b = smallBtn(t) { emoCat = i; draw() }
                if (i == emoCat) b.setBackgroundColor(ACC)
                strip.addView(b)
            }
            "clip" -> {
                strip.addView(smallBtn("＋ কপি করা আনুন") {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    addClip(cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""); draw()
                })
                var armed = false
                strip.addView(smallBtn("সব মুছুন") {
                    if (clips.isEmpty()) return@smallBtn
                    if (!armed) { armed = true; Toast.makeText(this, "আবার চাপুন", Toast.LENGTH_SHORT).show(); h.postDelayed({ armed = false }, 2500) }
                    else { clips.clear(); saveClips(); draw() }
                })
            }
        }
    }

    // ---------- emoji / clipboard ----------
    private fun emojis(i: Int): List<String> {
        if (i == 0) return recent
        return ecache.getOrPut(i) {
            val p = Paint(); val out = ArrayList<String>()
            if (i == 5) {
                "BD IN PK NP LK BT MV AF MM TH VN ID MY SG PH CN JP KR TW HK AE SA QA KW OM BH IR IQ TR EG PS JO LB SY IL US CA MX BR AR CL CO PE GB IE FR DE IT ES PT NL BE CH AT SE NO DK FI PL UA RU GR AU NZ ZA NG KE ET MA DZ".split(" ")
                    .forEach { c -> out.add(c.map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")) }
                return@getOrPut out
            }
            val ranges = when (i) {
                1 -> listOf(0x1F600..0x1F64F, 0x1F910..0x1F92F, 0x1F970..0x1F97B, 0x1F440..0x1F450, 0x1F466..0x1F487, 0x1F9D0..0x1F9DF, 0x1FAE0..0x1FAFF, 0x270A..0x270D)
                2 -> listOf(0x1F300..0x1F37F, 0x1F400..0x1F43F, 0x1F950..0x1F96F, 0x1F980..0x1F9CB, 0x1F345..0x1F37F)
                3 -> listOf(0x1F380..0x1F3FA, 0x1F680..0x1F6C5, 0x1F4A1..0x1F4FF, 0x1F507..0x1F52E, 0x1F9E7..0x1F9FF, 0x231A..0x231B, 0x23F0..0x23F3)
                else -> listOf(0x1F493..0x1F49F, 0x1F90D..0x1F90E, 0x2764..0x2764, 0x2705..0x2757, 0x1F500..0x1F506, 0x1F530..0x1F53D, 0x1F7E0..0x1F7EB, 0x2B05..0x2B1C, 0x2600..0x2604)
            }
            for (rg in ranges) for (cp in rg) {
                val s = String(Character.toChars(cp))
                if (p.hasGlyph(s) && !out.contains(s)) out.add(s)
            }
            out
        }
    }

    private fun scrollList(): Pair<ScrollView, LinearLayout> {
        val sv = ScrollView(this); val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        sv.addView(col); body.addView(sv, LinearLayout.LayoutParams(-1, dp(180)))
        return sv to col
    }

    private fun emojiView() {
        val col = scrollList().second
        val list = emojis(emoCat)
        if (list.isEmpty()) col.addView(TextView(this).apply { text = "এখনো কোনো ইমোজি ব্যবহার করেননি"; setTextColor(SUB); gravity = Gravity.CENTER; setPadding(0, dp(60), 0, 0) })
        list.chunked(8).forEach { ch ->
            val r = row()
            for (k in 0 until 8) {
                val e = ch.getOrNull(k)
                val t = TextView(this).apply {
                    text = e ?: ""; textSize = 24f; gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                    if (e != null) setOnClickListener {
                        commitComp(); currentInputConnection?.commitText(e, 1)
                        recent.remove(e); recent.add(0, e); if (recent.size > 40) recent.removeAt(40)
                        prefs.edit().putString("recent", JSONArray(recent).toString()).apply()
                    }
                }
                r.addView(t)
            }
            col.addView(r)
        }
    }

    private fun clipView() {
        val col = scrollList().second
        if (clips.isEmpty()) col.addView(TextView(this).apply { text = "কিছু সেভ করা নেই। কোনো লেখা কপি করলে এখানে জমা হবে।"; setTextColor(SUB); gravity = Gravity.CENTER; setPadding(dp(16), dp(50), dp(16), 0) })
        clips.toList().forEach { t ->
            val r = row(); r.gravity = Gravity.CENTER_VERTICAL; r.background = bgOf(KEY)
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(dp(2), 0, dp(2), dp(5)); r.layoutParams = lp
            r.addView(TextView(this).apply {
                text = t; setTextColor(INK); textSize = 16f; maxLines = 2; setPadding(dp(10), dp(8), dp(6), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { commitComp(); currentInputConnection?.commitText(t, 1) }
            })
            r.addView(TextView(this).apply {
                text = "✕"; setTextColor(SUB); gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(dp(44), dp(40))
                setOnClickListener { clips.remove(t); saveClips(); draw() }
            })
            col.addView(r)
        }
    }

    private fun addClip(t: String) {
        val s = t.trim(); if (s.isEmpty()) return
        clips.remove(s); clips.add(0, s); if (clips.size > 200) clips.removeAt(200); saveClips()
    }
    private fun saveClips() = prefs.edit().putString("clips", JSONArray(clips).toString()).apply()

    // ---------- typing ----------
    private fun commitComp() { if (roman.isNotEmpty()) { currentInputConnection?.finishComposingText(); roman.setLength(0) } }

    private fun type(out: String, avro: Boolean) {
        val ic = currentInputConnection ?: return
        if (avro && lang == 1 && out.length == 1 && (out[0] in 'a'..'z' || out[0] in 'A'..'Z' || out == "^")) {
            roman.append(out); ic.setComposingText(trans(roman.toString()), 1)
        } else {
            commitComp(); ic.commitText(if (lang > 0) bn(out) else out, 1)
            if (out.length == 1 && ",.।!?;:".contains(out)) learn()
        }
        if (shift) { shift = false; draw() } else updateSug()
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        if (roman.isNotEmpty()) {
            roman.setLength(roman.length - 1)
            if (roman.isEmpty()) { ic.setComposingText("", 1); ic.finishComposingText() } else ic.setComposingText(trans(roman.toString()), 1)
        } else {
            val sel = ic.getSelectedText(0)
            if (sel != null && sel.isNotEmpty()) ic.commitText("", 1) else ic.deleteSurroundingTextInCodePoints(1, 0)
        }
        updateSug()
    }

    private fun space() { commitComp(); currentInputConnection?.commitText(" ", 1); learn() }

    private fun enter() {
        commitComp(); learn()
        val ei = currentInputEditorInfo
        val a = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (ei != null && (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0 &&
            a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED) currentInputConnection?.performEditorAction(a)
        else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    // ---------- suggestions ----------
    private val sepEnd = Regex("[^\\s,।.!?;:()\"]*$")
    private val sepWord = Regex("([^\\s,।.!?;:()\"]+)\\s*$")

    private fun learn() {
        val ic = currentInputConnection ?: return
        val ws = (ic.getTextBeforeCursor(60, 0)?.toString() ?: "").split(Regex("[\\s,।.!?;:()\"]+")).filter { it.isNotEmpty() }
        val w = ws.lastOrNull()
        if (w != null && w.length <= 25) {
            lw.put(w, lw.optInt(w) + 1)
            val p = ws.getOrNull(ws.size - 2)
            if (p != null) { val o = bg.optJSONObject(p) ?: JSONObject().also { bg.put(p, it) }; o.put(w, o.optInt(w) + 1) }
            prefs.edit().putString("lw", lw.toString()).putString("bg", bg.toString()).apply()
        }
        updateSug()
    }

    private fun suggest(part: String, prev: String): List<String> {
        val out = ArrayList<String>(); fun add(w: String) { if (w.isNotEmpty() && !out.contains(w) && out.size < 3) out.add(w) }
        val en = lang == 0; val base = if (en) ENW else DICT
        if (part.isNotEmpty()) {
            val low = if (en) part.lowercase() else part
            lw.keys().asSequence().filter { it.startsWith(part) && it != part && en == Regex("[A-Za-z']+").matches(it) }
                .sortedByDescending { lw.optInt(it) }.forEach { add(it) }
            base.filter { it.startsWith(low) && it != part }.forEach { add(it) }
        } else {
            bg.optJSONObject(prev)?.let { n -> n.keys().asSequence().sortedByDescending { n.optInt(it) }.forEach { add(it) } }
            base.forEach { add(it) }
        }
        return out
    }

    private fun updateSug() {
        if (layer != "abc") return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
        val part = sepEnd.find(before)?.value ?: ""
        val prev = sepWord.find(before.dropLast(part.length))?.groupValues?.get(1) ?: ""
        curPart = part; sugWords = suggest(part, prev)
        for (i in 0..2) sug[i]?.text = sugWords.getOrElse(i) { "" }
    }

    private fun applySug(w: String) {
        val ic = currentInputConnection ?: return
        roman.setLength(0); ic.finishComposingText()
        ic.deleteSurroundingText(curPart.length, 0); ic.commitText("$w ", 1); learn()
    }
}
