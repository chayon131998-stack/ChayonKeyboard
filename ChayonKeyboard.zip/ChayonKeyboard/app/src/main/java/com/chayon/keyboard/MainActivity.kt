package com.chayon.keyboard

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); build() }
    override fun onResume() { super.onResume(); build() }

    private fun build() {
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((20 * d).toInt(), (40 * d).toInt(), (20 * d).toInt(), (20 * d).toInt())
        }
        fun tv(t: String, sz: Float, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sz; if (bold) setTypeface(null, Typeface.BOLD)
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        val on = imm.enabledInputMethodList.any { it.packageName == packageName }
        val cur = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.startsWith(packageName) == true
        col.addView(tv("Chayon কিবোড", 28f, true))
        col.addView(tv("বাংলা ও ইংরেজি কিবোড: অভ্র, প্রভাত, ইমোজি, কপি করা লেখা সেভ এবং শব্দের সাজেশন।", 15f))
        col.addView(tv("\nধাপ ১: কিবোড চালু করুন " + if (on) "✔" else "", 18f, true))
        col.addView(btn("কিবোড চালু করুন") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        col.addView(tv("\nধাপ ২: কিবোড বেছে নিন " + if (cur) "✔" else "", 18f, true))
        col.addView(btn("Chayon কিবোড বেছে নিন") { imm.showInputMethodPicker() })
        col.addView(tv("\nধাপ ৩: লিখে দেখুন", 18f, true))
        col.addView(EditText(this).apply { hint = "এখানে চেপে লিখুন…" })
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
